package TicTacToe;

public class Board {
	private char[][] board;

	public Board() {
		board= new char[3][3];
		initializeBoard();
	}
	
	private void initializeBoard() {
		for(int row=0;row<3;row++) {
			for(int column=0;column<3;column++) {
				board[row][column]= ' ';
			}
		}
	}
	public void display() {
		System.out.println("\n "+board[0][0]+" | "+board[0][1]+" | "+board[0][2]);
		System.out.println("---+---+---");
		System.out.println(" "+board[1][0]+" | "+board[1][1]+" | "+board[1][2]);
		System.out.println("---+---+---");
		System.out.println(" "+board[2][0]+" | "+board[2][1]+" | "+board[2][2]+"\n");
	}
	public boolean placeMark(int position,char mark) {
		int row=(position-1)/3;
		int column=(position-1)%3;
		if(board[row][column]!= ' ') {
			return false;
		}
		board[row][column]=mark;
		return true;
	}
	public boolean winner(char mark) {
		for(int row=0;row<3;row++) {
			if (board[row][0]== mark &&
				board[row][1]== mark &&
				board[row][2]== mark)
				return true;
		}
		for(int column=0;column<3;column++) {
			if (board[0][column]== mark &&
				board[1][column]== mark &&
				board[2][column]== mark)
				return true;
		}
		if (board[0][0]== mark &&
			board[1][1]== mark &&
			board[2][2]== mark)
				return true;
		if (board[0][2]== mark &&
			board[1][1]== mark &&
			board[2][0]== mark)
					return true;
		return false;
	}
	public boolean isFull() {
		for(int row=0;row<3;row++) {
			for(int column=0;column<3;column++) {
				if(board[row][column]==' ')
					return false;
			}
		}
		return true;
	}
}
