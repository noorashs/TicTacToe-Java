package TicTacToe;
import java.util.*;
public class Game {
	private Board board;
	private Scanner scn;
	public Game() {
		board=new Board();
		scn=new Scanner(System.in);
	}
	public void start() {
		char player ='X';
		while(true) {
			board.display();
			System.out.print("Player "+player+", choose a position(1-9): ");
			int position=scn.nextInt();
			if(position<1 || position>9) {
				System.out.println("Wrong number, Choose again(1-9): ");
				continue;
			}
			if(!board.placeMark(position, player)) {
				System.out.println("Position is taken.");
				continue;
			}
			if(board.winner(player)) {
				board.display();
				System.out.println("Player "+player+" Wins!!!");
				break;
			}
			if(board.isFull()) {
				board.display();
				System.out.println("DRAW!!");
				break;
			}
			player=(player=='X')? 'O':'X';
		}
		scn.close();
	}
}
